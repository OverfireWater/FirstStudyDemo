/*
Navicat MySQL Data Transfer

Source Server         : Mysql
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : lottery

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2022-11-12 19:35:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ip
-- ----------------------------
DROP TABLE IF EXISTS `ip`;
CREATE TABLE `ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ip
-- ----------------------------

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `monitor` int(30) NOT NULL,
  `study` int(30) NOT NULL,
  `leader` int(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '王鑫', '0', '0', '0');
INSERT INTO `student` VALUES ('2', '熊玉龙', '0', '0', '0');
INSERT INTO `student` VALUES ('3', '易磊', '0', '0', '0');
INSERT INTO `student` VALUES ('4', '卫东', '0', '0', '0');
INSERT INTO `student` VALUES ('5', '唐明杰', '0', '0', '0');
INSERT INTO `student` VALUES ('6', '苏茂', '0', '0', '0');
INSERT INTO `student` VALUES ('7', '蒲骏', '0', '0', '0');
INSERT INTO `student` VALUES ('8', '杨森', '0', '0', '0');
INSERT INTO `student` VALUES ('9', '刘鑫瑞', '0', '0', '0');
INSERT INTO `student` VALUES ('10', '刘同胜', '0', '0', '0');
INSERT INTO `student` VALUES ('11', '匡中友', '0', '0', '0');
INSERT INTO `student` VALUES ('12', '黄齐宣', '0', '0', '0');
INSERT INTO `student` VALUES ('13', '胡君', '0', '0', '0');
INSERT INTO `student` VALUES ('14', '何鑫', '0', '0', '0');
INSERT INTO `student` VALUES ('15', '宋洋', '0', '0', '0');
